A new design for a radar chart in D3.js. You can read more about in on the blog I wrote ["A different look for the D3 radar chart"](http://www.visualcinnamon.com/2015/10/different-look-d3-radar-chart.html)

An older version of a radar chart that I adjusted two years ago when I was just starting to learn D3.js can be found [here](http://bl.ocks.org/nbremer/6506614)